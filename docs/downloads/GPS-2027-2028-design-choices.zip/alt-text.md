# Alt text by design direction

Use the matching description below in place of the original design’s alt text.

## A — Bold editorial

**Simple announcement**

Crimson, warm white and black, bold uppercase typography and a Prague skyline photograph. Official Faculty of Social Sciences logo. Master in Geopolitical Studies at Charles University, Prague. 2027–2028. Applications open. Apply now. geopolitics.fsv.cuni.cz. The QR version includes a code linking to the GPS website; omit this sentence for the version without QR.

**Informative post**

Crimson, warm white and black, bold uppercase typography and a Prague skyline photograph. Official Faculty of Social Sciences logo. Master in Geopolitical Studies at Charles University, Prague. Career-focused program: shape the world you want to live in. Taught entirely in English; students from 60+ countries; double degree with National Taiwan University; learn from practitioners and diplomats; careers in diplomacy, business, academia and beyond; scholarships available, subject to eligibility. Apply now for the 2027–2028 academic year. geopolitics.fsv.cuni.cz. The QR version includes a code linking to the GPS website; omit this sentence for the version without QR.

## B — Prague after dark

**Simple announcement**

Deep navy, white serif typography and a Prague skyline photograph. Official Faculty of Social Sciences logo. Master in Geopolitical Studies at Charles University, Prague. 2027–2028. Applications open. Apply now. geopolitics.fsv.cuni.cz. The QR version includes a code linking to the GPS website; omit this sentence for the version without QR.

**Informative post**

Deep navy, white serif typography and a Prague skyline photograph. Official Faculty of Social Sciences logo. Master in Geopolitical Studies at Charles University, Prague. Career-focused program: shape the world you want to live in. Taught entirely in English; students from 60+ countries; double degree with National Taiwan University; learn from practitioners and diplomats; careers in diplomacy, business, academia and beyond; scholarships available, subject to eligibility. Apply now for the 2027–2028 academic year. geopolitics.fsv.cuni.cz. The QR version includes a code linking to the GPS website; omit this sentence for the version without QR.

## C — Campus & community

**Simple announcement**

White and crimson, open sans-serif typography and an authentic university group photograph. Official Faculty of Social Sciences logo. Master in Geopolitical Studies at Charles University, Prague. 2027–2028. Applications open. Apply now. geopolitics.fsv.cuni.cz. The QR version includes a code linking to the GPS website; omit this sentence for the version without QR.

**Informative post**

White and crimson, open sans-serif typography and an authentic university group photograph. Official Faculty of Social Sciences logo. Master in Geopolitical Studies at Charles University, Prague. Career-focused program: shape the world you want to live in. Taught entirely in English; students from 60+ countries; double degree with National Taiwan University; learn from practitioners and diplomats; careers in diplomacy, business, academia and beyond; scholarships available, subject to eligibility. Apply now for the 2027–2028 academic year. geopolitics.fsv.cuni.cz. The QR version includes a code linking to the GPS website; omit this sentence for the version without QR.

## D — Academic classic

**Simple announcement**

White and crimson with a formal serif heading, a fine border and no photograph. Official Faculty of Social Sciences logo. Master in Geopolitical Studies at Charles University, Prague. 2027–2028. Applications open. Apply now. geopolitics.fsv.cuni.cz. The QR version includes a code linking to the GPS website; omit this sentence for the version without QR.

**Informative post**

White and crimson with a formal serif heading, a fine border and no photograph. Official Faculty of Social Sciences logo. Master in Geopolitical Studies at Charles University, Prague. Career-focused program: shape the world you want to live in. Taught entirely in English; students from 60+ countries; double degree with National Taiwan University; learn from practitioners and diplomats; careers in diplomacy, business, academia and beyond; scholarships available, subject to eligibility. Apply now for the 2027–2028 academic year. geopolitics.fsv.cuni.cz. The QR version includes a code linking to the GPS website; omit this sentence for the version without QR.
