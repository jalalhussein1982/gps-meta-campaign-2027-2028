# GPS Meta advertising copy

Prepared for the planned campaign beginning **1 November 2026**, advertising the **2027–2028 academic year**. “Applications open” and “Apply now” are launch copy; do not publish them before the opening date. This academic year matches the official GPS website's 2027/2028 enrollment announcement.

## Simple announcement

**Primary text**

Applications are open for the 2027–2028 Master in Geopolitical Studies at Charles University, Prague. Explore the program.

**Headline**

MA in Geopolitical Studies

**Description**

2027–2028 academic year

**Button**

Learn more

**Destination**

https://geopolitics.fsv.cuni.cz/

**Alt text**

Use the matching entry in `alt-text.md`.

## Informative post

**Primary text**

Careers in diplomacy, business, academia and beyond. Explore the Master in Geopolitical Studies at Charles University, Prague.

**Optional longer primary text**

Career-focused program: shape the world you want to live in.

Study entirely in English, join a community from 60+ countries, and learn from practitioners and diplomats. Explore the double degree with National Taiwan University. Partial scholarship opportunities are subject to eligibility and current conditions.

Applications are open for the 2027–2028 academic year.

**Headline**

Study Geopolitical Studies

**Description**

Charles University · Prague

**Button**

Learn more

**Destination**

https://geopolitics.fsv.cuni.cz/

**Alt text**

Use the matching entry in `alt-text.md`.
